#!/bin/sh
echo "Applying  Patch on pfSense.........
.
.
.
0%  10% 20%  30%  40%  50% 60% 70% 80%  90% 100%"

# Add your patch commands here
echo "Patch Applied Successfully!"
