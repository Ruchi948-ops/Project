#!/bin/bash

cat << "EOF"
Applying Patch on Linux.........
0% 10% 20% 30% 40% 50% 60% 70% 80% 90% 100%
EOF

echo "Patch Applied Successfully!"

echo "Sleeping for 10 seconds..."
sleep 10
